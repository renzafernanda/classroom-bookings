<?php

$lang['bookings_legend_legend'] = 'Legend';
$lang['bookings_legend_free'] = 'Free';
$lang['bookings_legend_static'] = 'Timetabled lesson';
$lang['bookings_legend_staff'] = 'Staff booking';
