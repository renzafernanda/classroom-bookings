<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['error_prefix'] = '<p class="hint error"><span>';
$config['error_suffix'] = '</span></p>';
