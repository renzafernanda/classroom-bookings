<dl>
  <dt>User details</dt>
  <dd>Make changes to your user details, such as your display name and email address here.</dd>

  <dt>Change password</dt>
  <dd>To change your password, please enter your new password <i>twice</i> in the <span>password</span> fields.</dd>
</dl>