<dl>
	<dt>Database</dt>
	<dd>Enter your database details here.</dd>
	<dd>Ensure the database has been created, and the user has access to it.</dd>
</dl>
