<p class="msgbox info"><?php echo $vars; ?></p>
