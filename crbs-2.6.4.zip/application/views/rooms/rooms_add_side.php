<dl>
  <dt>Room Information</dt>
  <dd>The only required field for a room is the <span>name</span> field. All of the other fields are there to help yourself and other users.</dd>
</dl>
