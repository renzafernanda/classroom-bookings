<div class="tab-pane">
	<div class="block-group">
		<div class="block b-30 tab-pane-list">
			<?= $list_html ?>
		</div>
		<div class="block b-70 tab-pane-detail">
			<?= $detail_html ?>
		</div>
	</div>
</div>
